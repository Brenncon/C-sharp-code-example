﻿namespace Assignment2
{
    partial class Add_Cars_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.LicensePlate = new System.Windows.Forms.Label();
            this.CarType = new System.Windows.Forms.Label();
            this.ModelYear = new System.Windows.Forms.Label();
            this.Miles = new System.Windows.Forms.Label();
            this.Make = new System.Windows.Forms.Label();
            this.MarketPrice = new System.Windows.Forms.Label();
            this.CarImage = new System.Windows.Forms.Button();
            this.AddRecord = new System.Windows.Forms.Button();
            this.ViewReport = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(121, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(350, 18);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(121, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextChanged += new System.EventHandler(this.TextBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(350, 59);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(121, 20);
            this.textBox3.TabIndex = 2;
            this.textBox3.TextChanged += new System.EventHandler(this.TextBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(121, 146);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(121, 20);
            this.textBox4.TabIndex = 3;
            this.textBox4.TextChanged += new System.EventHandler(this.TextBox4_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Mercedes-Benz ",
            "Suzuki",
            "DATSUN",
            "Volvo"});
            this.comboBox1.Location = new System.Drawing.Point(121, 62);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012"});
            this.comboBox2.Location = new System.Drawing.Point(121, 105);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 5;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.ComboBox2_SelectedIndexChanged);
            // 
            // LicensePlate
            // 
            this.LicensePlate.AutoSize = true;
            this.LicensePlate.Location = new System.Drawing.Point(44, 25);
            this.LicensePlate.Name = "LicensePlate";
            this.LicensePlate.Size = new System.Drawing.Size(71, 13);
            this.LicensePlate.TabIndex = 6;
            this.LicensePlate.Text = "License Plate";
            // 
            // CarType
            // 
            this.CarType.AutoSize = true;
            this.CarType.Location = new System.Drawing.Point(65, 65);
            this.CarType.Name = "CarType";
            this.CarType.Size = new System.Drawing.Size(50, 13);
            this.CarType.TabIndex = 7;
            this.CarType.Text = "Car Type";
            // 
            // ModelYear
            // 
            this.ModelYear.AutoSize = true;
            this.ModelYear.Location = new System.Drawing.Point(54, 108);
            this.ModelYear.Name = "ModelYear";
            this.ModelYear.Size = new System.Drawing.Size(61, 13);
            this.ModelYear.TabIndex = 8;
            this.ModelYear.Text = "Model Year";
            // 
            // Miles
            // 
            this.Miles.AutoSize = true;
            this.Miles.Location = new System.Drawing.Point(84, 149);
            this.Miles.Name = "Miles";
            this.Miles.Size = new System.Drawing.Size(31, 13);
            this.Miles.TabIndex = 9;
            this.Miles.Text = "Miles";
            // 
            // Make
            // 
            this.Make.AutoSize = true;
            this.Make.Location = new System.Drawing.Point(310, 21);
            this.Make.Name = "Make";
            this.Make.Size = new System.Drawing.Size(34, 13);
            this.Make.TabIndex = 10;
            this.Make.Text = "Make";
            // 
            // MarketPrice
            // 
            this.MarketPrice.AutoSize = true;
            this.MarketPrice.Location = new System.Drawing.Point(277, 62);
            this.MarketPrice.Name = "MarketPrice";
            this.MarketPrice.Size = new System.Drawing.Size(67, 13);
            this.MarketPrice.TabIndex = 11;
            this.MarketPrice.Text = "Market Price";
            // 
            // CarImage
            // 
            this.CarImage.Location = new System.Drawing.Point(280, 99);
            this.CarImage.Name = "CarImage";
            this.CarImage.Size = new System.Drawing.Size(75, 23);
            this.CarImage.TabIndex = 12;
            this.CarImage.Text = "Car Image";
            this.CarImage.UseVisualStyleBackColor = true;
            this.CarImage.Click += new System.EventHandler(this.CarImage_Click);
            // 
            // AddRecord
            // 
            this.AddRecord.Location = new System.Drawing.Point(167, 339);
            this.AddRecord.Name = "AddRecord";
            this.AddRecord.Size = new System.Drawing.Size(75, 23);
            this.AddRecord.TabIndex = 13;
            this.AddRecord.Text = "Add Record";
            this.AddRecord.UseVisualStyleBackColor = true;
            this.AddRecord.Click += new System.EventHandler(this.AddRecord_Click);
            // 
            // ViewReport
            // 
            this.ViewReport.Location = new System.Drawing.Point(350, 339);
            this.ViewReport.Name = "ViewReport";
            this.ViewReport.Size = new System.Drawing.Size(75, 23);
            this.ViewReport.TabIndex = 14;
            this.ViewReport.Text = "View Report";
            this.ViewReport.UseVisualStyleBackColor = true;
            this.ViewReport.Click += new System.EventHandler(this.ViewReport_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(371, 99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(174, 147);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // Add_Cars_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 387);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ViewReport);
            this.Controls.Add(this.AddRecord);
            this.Controls.Add(this.CarImage);
            this.Controls.Add(this.MarketPrice);
            this.Controls.Add(this.Make);
            this.Controls.Add(this.Miles);
            this.Controls.Add(this.ModelYear);
            this.Controls.Add(this.CarType);
            this.Controls.Add(this.LicensePlate);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Add_Cars_Form";
            this.Text = "Add_Cars_Form";
            this.Load += new System.EventHandler(this.Add_Cars_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label LicensePlate;
        private System.Windows.Forms.Label CarType;
        private System.Windows.Forms.Label ModelYear;
        private System.Windows.Forms.Label Miles;
        private System.Windows.Forms.Label Make;
        private System.Windows.Forms.Label MarketPrice;
        private System.Windows.Forms.Button CarImage;
        private System.Windows.Forms.Button AddRecord;
        private System.Windows.Forms.Button ViewReport;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}