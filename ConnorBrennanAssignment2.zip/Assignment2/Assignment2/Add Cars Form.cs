﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Assignment2.Logic;

namespace Assignment2
{
    public partial class Add_Cars_Form : Form
    {
        //declare variables
        private string _licensePlateTxt = "";
        private string _carTypeTxt = "";
        private string _modelYearTxt = "";
        private string _milesTxt = "";
        private string _carMakeTxt = "";
        private string _marketPriceTxt = "";
        private string _imagePath = "";

        private int _modelYear = 0;
        private float _marketPrice = 0;
        private int _miles = 0;

        private List<Cars> _cars = new List<Cars>();

        public Add_Cars_Form()
        {
            InitializeComponent();

            //centers the form on run time
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        /// <summary>
        /// receives the users input, and adds it to an instance of car,
        /// then adds it to the list of cars, prints a message upon 
        /// success, and resets the input fields
        /// </summary>
        private void AddRecord_Click(object sender, EventArgs e)
        {
            Cars car = new Cars();

            _licensePlateTxt = textBox1.Text;
            _carTypeTxt = comboBox1.SelectedItem.ToString();
            _modelYearTxt = comboBox2.SelectedItem.ToString();
            _milesTxt = textBox4.Text;
            _carMakeTxt = textBox2.Text;
            _marketPriceTxt = textBox3.Text;

            _modelYear = int.Parse(_modelYearTxt);
            _marketPrice = float.Parse(_marketPriceTxt);
            _miles = int.Parse(_milesTxt);

            _imagePath = pictureBox1.ImageLocation;

            car.AddCar(_licensePlateTxt, _carTypeTxt, _carMakeTxt, _modelYear, _imagePath,
            _marketPrice, _miles);

            _cars.Add(car);

            DialogResult result = MessageBox.Show("New car record added.");
            

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;

        }

        /// <summary>
        /// when the button ViewReport is clicked, open the Report Form
        /// </summary>
        private void ViewReport_Click(object sender, EventArgs e)
        {

            Report_Form report_form = new Report_Form(_cars);
            report_form.ShowDialog();
        }

        /// <summary>
        /// When the button CarImage is clicked, open up a dialog menu to allow the user to add
        /// a car image to the car record
        /// </summary>
        private void CarImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            DialogResult result = openFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                pictureBox1.ImageLocation = openFileDialog.FileName;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            //license plate text box
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //car type combo box
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //model year combo box
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {
            //miles text box
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            //make text box
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            //market price text box
        }

        private void Add_Cars_Form_Load(object sender, EventArgs e)
        {
            
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
