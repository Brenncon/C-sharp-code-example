﻿namespace Assignment2
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ToAddCars = new System.Windows.Forms.Button();
            this.ToReport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ToAddCars
            // 
            this.ToAddCars.Location = new System.Drawing.Point(219, 176);
            this.ToAddCars.Name = "ToAddCars";
            this.ToAddCars.Size = new System.Drawing.Size(104, 23);
            this.ToAddCars.TabIndex = 0;
            this.ToAddCars.Text = "To Add Cars Form";
            this.ToAddCars.UseVisualStyleBackColor = true;
            this.ToAddCars.Click += new System.EventHandler(this.ToAddCars_Click);
            // 
            // ToReport
            // 
            this.ToReport.Location = new System.Drawing.Point(470, 176);
            this.ToReport.Name = "ToReport";
            this.ToReport.Size = new System.Drawing.Size(97, 23);
            this.ToReport.TabIndex = 1;
            this.ToReport.Text = "To Report Form";
            this.ToReport.UseVisualStyleBackColor = true;
            this.ToReport.Click += new System.EventHandler(this.ToReport_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ToReport);
            this.Controls.Add(this.ToAddCars);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ToAddCars;
        private System.Windows.Forms.Button ToReport;
    }
}