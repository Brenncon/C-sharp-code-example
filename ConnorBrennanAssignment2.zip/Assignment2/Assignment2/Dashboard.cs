﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Assignment2.Logic;

namespace Assignment2
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();

            //centers the screen on run time
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        /// <summary>
        /// when the button ToAddCars is clicked, open the Add Cars Form
        /// </summary>
        private void ToAddCars_Click(object sender, EventArgs e)
        {
            Add_Cars_Form _add_cars_form = new Add_Cars_Form();
            _add_cars_form.ShowDialog();

        }

        /// <summary>
        /// when the button ToReport is clicked, open the Report Form
        /// </summary>
        private void ToReport_Click(object sender, EventArgs e)
        {
            List<Cars> _blank = new List<Cars>();

            Report_Form _report_form = new Report_Form(_blank);
            _report_form.ShowDialog();

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
