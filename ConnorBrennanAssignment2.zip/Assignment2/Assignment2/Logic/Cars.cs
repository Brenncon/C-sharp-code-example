﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Logic
{
    public class Cars
    {
        //Variable declaration
        public string _licensePlateNo { get; set; } = "";
        private static string[] _allLicensePlateNos = new string[30];

        public string _type { get; set; } = "";
        public string _make { get; set; } = "";
        public int _modelYear { get; set; } = 0;
        public string _imagePath { get; set; } = "";
        public float _marketPrice { get; set; } = 0;
        public int _miles { get; set; } = 0;
        public string _totalDepreciation { get; set; } = "";

        private int counter = 0;
        public int _yearNum { get; set; } = 0;
        public int _milesNum { get; set; } = 0;

        /// <summary>
        ///Gets a license plate number and only adds it to the program
        ///if the input is not blank or null, and if there is no duplicate
        /// </summary>
        private void LicensePlateNo(string license)
        {
            for (int i = 0; i < 15; i++)
            {
                if (license.Equals(_allLicensePlateNos[i]))
                {
                    throw new System.ArgumentException("Cannot add duplicate cars");
                }

                if (string.IsNullOrEmpty(license) == true)
                {
                    throw new System.ArgumentException("License plate number is a required field");
                }
            }

            //Adds user input to the total of all inputted license plates
            //to ensure no duplicate values. while also adding it to
            //_licensePlateNo for later calculations. Only if the data is not
            //null or blank
            if (string.IsNullOrEmpty(license) == false) {
                _licensePlateNo = license;
                _allLicensePlateNos[counter] = license;
                counter = counter + 1;
            }
        }

        /// <summary>
        ///Adds car type to the program without any checks as it is not a required field
        /// </summary>
        private void Type(string carType)
        {
            _type = carType;
        }

        /// <summary>
        ///Only adds car make to the program if the input is not blank or null
        /// </summary>
        private void Make(string carMake)
        {
            if (string.IsNullOrEmpty(carMake) == true)
            {
                throw new System.ArgumentException("Car make is a required field");
            }
            else
            {
                _make = carMake;
            }
        }

        /// <summary>
        ///Adds model year to the program without any checks as it is not a required field,
        ///and turns it into a string to display it on the screen later
        /// </summary>
        private void ModelYear(int mYear)
        {
            mYear = 2019 - mYear;

            if (mYear > 5)
            {
                throw new System.ArgumentException("Cars that are over 5 years old will not be accepted");
            }
            else
            {
                _modelYear = mYear;
                _yearNum = mYear;
            }
        }

        /// <summary>
        ///Gets the image path and adds it to the program if it is not blank, or null
        /// </summary>
        private void ImagePath(string imgPath)
        {
            if (string.IsNullOrEmpty(imgPath) == true)
            {
                throw new System.ArgumentException("Image path is a required field");
            }
            else
            {
                _imagePath = imgPath;
            }
        }

        /// <summary>
        ///Gets the market price and adds it to the program if it is not less then or equal to 0
        /// </summary>
        private void MarketPrice(float mPrice)
        {
            if (mPrice <= 0)
            {
                throw new System.ArgumentException("Market price cannot be less then or equal to zero");
            }
            else
            {
                _marketPrice = mPrice;
            }
        }

        /// <summary>
        ///Gets the miles and adds it to the program if it is not less then or equal to 0
        /// </summary>
        private void Miles(int miles)
        {
            if (miles <= 0)
            {
                throw new System.ArgumentException("Miles cannot be less then or equal to zero");
            }
            else if (miles > 110000)
            {
                throw new System.ArgumentException("Miles that are over 110,000Km will not be accepted");
            }
            else
            {
                _marketPrice = miles;
                _milesNum = miles;
            }
        }

        /// <summary>
        ///Calculates the yearly depreciation, and the miles depreciation and adds them together 
        ///for the total depreciation. Only if the years on the car are not greater then 5, and
        ///the miles on the car are not greater then 110000
        /// </summary>
        private void TotalDepreciation()
        {
            double _yearDep = (2019 - _yearNum) * 10;
            double _milesDep = 0;
            double _milesHolder = _milesNum;
            double _totalDep = 0;
            while (_milesHolder >= 10000)
            {
                _milesHolder = _milesHolder - 10000;
                _milesDep = _milesDep + .9;
            }

            _totalDep = _yearDep + _milesDep;
            _totalDepreciation = _totalDep.ToString();
        }

        /// <summary>
        ///calls all necessary methods to add a car record to the program
        /// </summary>
        public void AddCar(string license, string carType, string carMake, int mYear, string imgPath,
            float mPrice, int miles)
        {
            LicensePlateNo(license);
            Type(carType);
            Make(carMake);
            ModelYear(mYear);
            ImagePath(imgPath);
            MarketPrice(mPrice);
            Miles(miles);
            TotalDepreciation();
    }

    }
}
