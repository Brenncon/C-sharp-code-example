﻿namespace Assignment2
{
    partial class Report_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CarDetails = new System.Windows.Forms.Label();
            this.MarketValue = new System.Windows.Forms.Label();
            this.DepreciatedValue = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.addCarsFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addCarsFormBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // CarDetails
            // 
            this.CarDetails.AutoSize = true;
            this.CarDetails.Location = new System.Drawing.Point(12, 9);
            this.CarDetails.Name = "CarDetails";
            this.CarDetails.Size = new System.Drawing.Size(58, 13);
            this.CarDetails.TabIndex = 0;
            this.CarDetails.Text = "Car Details";
            // 
            // MarketValue
            // 
            this.MarketValue.AutoSize = true;
            this.MarketValue.Location = new System.Drawing.Point(101, 421);
            this.MarketValue.Name = "MarketValue";
            this.MarketValue.Size = new System.Drawing.Size(73, 13);
            this.MarketValue.TabIndex = 1;
            this.MarketValue.Text = "Market Value:";
            // 
            // DepreciatedValue
            // 
            this.DepreciatedValue.AutoSize = true;
            this.DepreciatedValue.Location = new System.Drawing.Point(383, 421);
            this.DepreciatedValue.Name = "DepreciatedValue";
            this.DepreciatedValue.Size = new System.Drawing.Size(98, 13);
            this.DepreciatedValue.TabIndex = 2;
            this.DepreciatedValue.Text = "Depreciated Value:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(180, 418);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(487, 418);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(691, 369);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellContentClick);
            // 
            // addCarsFormBindingSource
            // 
            this.addCarsFormBindingSource.DataSource = typeof(Assignment2.Add_Cars_Form);
            // 
            // Report_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.DepreciatedValue);
            this.Controls.Add(this.MarketValue);
            this.Controls.Add(this.CarDetails);
            this.Name = "Report_Form";
            this.Text = "Report_Form";
            this.Load += new System.EventHandler(this.Report_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addCarsFormBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CarDetails;
        private System.Windows.Forms.Label MarketValue;
        private System.Windows.Forms.Label DepreciatedValue;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource addCarsFormBindingSource;
    }
}