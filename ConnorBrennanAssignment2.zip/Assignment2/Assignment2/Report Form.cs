﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Assignment2.Logic;

namespace Assignment2
{
    public partial class Report_Form : Form
    {
        //Variable declaration
        private List<Cars> _cars;

        /// <summary>
        /// sets the form to the center of the screen,
        /// gets a car list and makes report forms car list equal 
        /// to the incomming car list
        /// </summary>
        public Report_Form(List<Cars> cars)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            _cars = cars;
           
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        /// <summary>
        /// puts the data from the car list onto the grid view on the screen
        /// </summary>
        private void Report_Form_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = _cars;
            
        }
    }
}
